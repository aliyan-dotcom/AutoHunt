"""
AutoHunt - Attack Log Parser & MITRE ATT&CK Mapping API
---------------------------------------------------------
Reads Cowrie honeypot JSON logs, extracts attacker events,
maps them to MITRE ATT&CK techniques, and serves a summary
over a Flask HTTPS API for the React dashboard to consume.

Run this INSIDE the cowrie user's virtual environment on the
DigitalOcean droplet (or wherever your honeypot lives).
"""

import json
import os
from collections import Counter, defaultdict
from datetime import datetime

from flask import Flask, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # allow the React dashboard (different origin) to call this API

# Path to the Cowrie JSON log file
COWRIE_LOG_PATH = os.path.expanduser("~/var/log/cowrie/cowrie.json")

# --- MITRE ATT&CK technique mapping ---------------------------------
MITRE_MAP = {
    "cowrie.login.failed": ("T1110", "Brute Force"),
    "cowrie.login.success": ("T1078", "Valid Accounts"),
    "cowrie.session.file_download": ("T1105", "Ingress Tool Transfer"),
    "cowrie.command.input": ("T1059", "Command and Scripting Interpreter"),
    "cowrie.client.version": ("T1595", "Active Scanning"),
}

COMMAND_KEYWORDS = {
    "uname": ("T1082", "System Information Discovery"),
    "cat /etc/passwd": ("T1003", "OS Credential Dumping"),
    "wget": ("T1105", "Ingress Tool Transfer"),
    "curl": ("T1105", "Ingress Tool Transfer"),
}


def parse_logs():
    events = []
    technique_counts = Counter()
    attacker_ips = Counter()
    sessions = defaultdict(list)

    if not os.path.exists(COWRIE_LOG_PATH):
        return {
            "status": "no_logs_found",
            "total_events": 0,
            "unique_attackers": 0,
            "techniques": [],
            "recent_events": [],
        }

    with open(COWRIE_LOG_PATH, "r") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            eventid = entry.get("eventid", "")
            src_ip = entry.get("src_ip", "unknown")
            timestamp = entry.get("timestamp", "")
            session = entry.get("session", "unknown")

            technique_id, technique_name = None, None

            if eventid == "cowrie.command.input":
                cmd = entry.get("input", "")
                matched = False
                for keyword, (tid, tname) in COMMAND_KEYWORDS.items():
                    if keyword in cmd:
                        technique_id, technique_name = tid, tname
                        matched = True
                        break
                if not matched:
                    technique_id, technique_name = MITRE_MAP.get(eventid, (None, None))
            else:
                technique_id, technique_name = MITRE_MAP.get(eventid, (None, None))

            if technique_id:
                technique_counts[f"{technique_id} - {technique_name}"] += 1

            attacker_ips[src_ip] += 1

            event_summary = {
                "timestamp": timestamp,
                "src_ip": src_ip,
                "eventid": eventid,
                "session": session,
                "technique": f"{technique_id} - {technique_name}" if technique_id else None,
            }
            events.append(event_summary)
            sessions[session].append(event_summary)

    events_sorted = sorted(events, key=lambda e: e["timestamp"], reverse=True)

    return {
        "status": "ok",
        "generated_at": datetime.utcnow().isoformat() + "Z",
        "total_events": len(events),
        "unique_attackers": len(attacker_ips),
        "top_attacker_ips": attacker_ips.most_common(10),
        "techniques": technique_counts.most_common(),
        "recent_events": events_sorted[:50],
    }


@app.route("/api/summary", methods=["GET"])
def summary():
    return jsonify(parse_logs())


@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "alive"})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, ssl_context="adhoc")
