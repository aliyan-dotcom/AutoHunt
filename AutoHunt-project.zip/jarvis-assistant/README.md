# Jarvis — AutoHunt Voice Assistant

A voice-controlled companion app for AutoHunt. Talk to it (or type) and
it answers questions about the project — architecture, tech stack
choices, MITRE ATT&CK mapping, troubleshooting steps, restart
commands — and can quiz you for your project defense.

## Live version

The easiest way to use this is the already-published, hosted version,
which works straight away on a phone browser with no setup:

https://claude.ai/artifact/V7Y4u2VDZaDNbwL9emn4NS

Open it on your phone and add it to your home screen so it behaves
like a normal app icon.

## Running it yourself

`jarvis.html` is a single self-contained HTML file. It relies on a
Claude-powered "ask AI" capability that is only granted when the page
is opened through claude.ai (via the link above, or by re-publishing
it as a Claude Artifact). Opening the raw file directly in a browser
(e.g. by double-clicking it) will load the interface, but the
AI-answering feature will show a message saying it can't be reached,
since that capability isn't available outside claude.ai.

Voice input uses the browser's built-in Speech Recognition API
(works well in Chrome on Android; more limited on iOS Safari — a text
box is always available as a fallback). Voice output uses the
browser's built-in text-to-speech.

## Live status data

Because of browser security rules, a published page can't silently
fetch data from an external server like the AutoHunt Flask API in the
background. So instead, tap the small refresh icon in the top-right
corner and either:

- paste the full JSON response from `https://YOUR_DROPLET_IP:5000/api/summary`, or
- type the total event count and attacker count in manually

Jarvis remembers this reading (stored only on your own device) and
uses it to answer status questions until you refresh it again.
